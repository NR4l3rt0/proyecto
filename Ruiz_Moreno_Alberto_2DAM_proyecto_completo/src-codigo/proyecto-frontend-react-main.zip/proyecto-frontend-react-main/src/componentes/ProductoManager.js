// Esta se trataría de una clase que podría servir de unión para compartir estados entre componentes,
// está prevista para ser un enlace más complejo y/o se plantea el uso con Redux.
// Incitaría a una lógica distribuida entre productos-almacenes-pedido de clientes.
// No se ha podido seguir esta vía.