#!/bin/sh
docker rm -f postgresDB;
