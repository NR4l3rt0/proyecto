insert into pedido_cliente(pk_id_pedido, coste_pedido, estado_pedido, fecha_entrega, fecha_pedido,
                           forma_pago, tipo_pedido, fk_id_almacen, fk_id_nro_empleado, fk_id_nro_socio)
                           values(aaab5574-4777-4b70-a9db-c1309009a67d, '320.20', 'solicitado', null, 
                                    '2021-04-17', 'online', 'online', 1, 1, 3),
                                 (bbbf5574-4777-4b70-a9db-c1309009a67d, '220.20', 'solicitado', null,
                                    '2021-03-21', 'online', 'online', 1, 2, 3),
                                 (cccb5574-4777-4b70-a9db-c1309009a67d, '220.20', 'confirmado', null,
                                    '2021-05-02', 'online', 'online', 1, 1, 1),
                                 (dddb5574-4777-4b70-a9db-c1309009a67d, '70.20', 'cancelado', '2021-03-13',
                                    '2021-03-30', 'online', 'online', 1, 3, 2);

